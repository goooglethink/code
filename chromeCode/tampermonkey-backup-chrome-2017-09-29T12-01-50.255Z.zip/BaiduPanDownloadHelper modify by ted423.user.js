// ==UserScript==
// @id             baidupan@ywzhaiqi@gmail.com
// @name           BaiduPanDownloadHelper modify by ted423
// @version        2016.12.13.1
// @namespace      https://github.com/ywzhaiqi
// @author         ywzhaiqi
// @description    This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @grant          GM_addStyle
// @grant          GM_setClipboard
// @grant          GM_openInTab
// @grant          GM_xmlhttpRequest
// @homepageURL    https://greasyfork.org/scripts/294/
// 兼容 GM 1.x, 2.x


// @license        GPL version 3
// @include        http*://yun.baidu.com/share/*
// @include        http*://pan.baidu.com/share/*
// @include        http*://yun.baidu.com/s/*
// @include        http*://pan.baidu.com/s/*
// @include        http*://pan.baidu.com/wap/*
// @include        http*://yun.baidu.com/wap/*
// @include        http*://yun.baidu.com/pcloud/album/*
// @include        http*://pan.baidu.com/pcloud/album/*
// @include        http*://pan.baidu.com/disk/home*
// @include        http*://yun.baidu.com/disk/home*
// @run-at         document-start
// ==/UserScript==
