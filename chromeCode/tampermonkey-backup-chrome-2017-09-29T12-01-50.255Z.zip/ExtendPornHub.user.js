// ==UserScript==
// @author			Jack_mustang
// @version			2.0
// @name			ExtendPornHub
// @description		Remove ads, enlarges video, stops autoplay keeping buffering & block pop-ups
// @date			2016 August 19
// @include			*pornhub.com/*
// @include			*pornhubpremium.com/*
// @run-at			document-start
// @grant			none
// @license			Public Domain
// @icon			https://gmgmla.dm2301.livefilestore.com/y2pAKJYeZAp4tG23hG68x1mRuEUQXqb1MxdLbuqVnyyuHFxC7ra5Fc-tfq6hD-r9cNnVufT3egUHaimL547xDlESrOVmQsqNSJ5gzaiSccLYzo/ExtendPornHub-logo.png
// @namespace		649b97180995e878e7e91b2957ef3bbee0f840a0
// ==/UserScript==
var premium = window.location.hostname.search("premium")
var ephcic = 0
var ephcpc = 0

if (premium > 0) {
	var ExtendPHP = function ExtendPornHubPremium(){
		changePlayer()
		window.addEventListener('DOMContentLoaded', function(){
			if(document.querySelector("#player"))
				videoFunctions()
		}, false)
	}();
	return;
}

// Block popups
function NoOpen(e){return 1}
parent.open=NoOpen;
this.open=NoOpen;
window.open=NoOpen;
open=NoOpen;
window.open = function(){return;}
open = function(){return;}
this.open = function(){return;}
parent.open = function(){return;}

// Block ads
window.__defineGetter__("adDelivery", function() {return null})
window.__defineSetter__("adDelivery", function() {return null})
window.__defineGetter__("AdDelivery", function() {return null})
window.__defineSetter__("AdDelivery", function() {return null})

window.g367CB268B1094004A3689751E7AC568F = {
	Core: "stop mouse tracking and popups"
}
window.blockpops = document.createElement("iframe")
blockpops.src = "http://ss.phncdn.com/iframe-1.1"
addBlock()
function addBlock() {
	if (!document.querySelector("body"))
		return setTimeout(addBlock, 50)
	document.body.appendChild(blockpops)
}

// Begin page manipulation
var ExtendPH = function ExtendPornHub(){
	addStyle()
	changePlayer()

	window.addEventListener('DOMContentLoaded', function(){
		// Remove ads functions
		function removeQuery(query) {
			var ifr = document.querySelectorAll(query)
			if(ifr.length > 0)
				for(var i=0; i < ifr.length; i++)
					if(query !== "iframe" || ifr[i].src !== "http://ss.phncdn.com/iframe-1.1") // This page yelds 404 and it blocks popups, seriously
						ifr[i].parentNode.removeChild(ifr[i])
		}
		// Remove those elements because they are ads
		removeQuery("iframe")
		removeQuery("aside")
		removeQuery("figure")

		// Video page
		if(document.getElementById('player')) {
			videoFunctions()

			// Add video download when not logged
			if( document.body.classList[0].search("logged-in") < 0 ) {
				var tab = document.querySelector(".download-tab"),
					dwlinks

				if(player_quality_720p)
					dwlinks = '<a class="downloadBtn greyButton" target="_blank" href="'+player_quality_720p+'"><i></i><span>HD</span> 720p</a>'
				if(player_quality_480p)
					dwlinks += '<a class="downloadBtn greyButton" target="_blank" href="'+player_quality_480p+'"><i></i>480p</a>'
				if(player_quality_240p)
					dwlinks += '<a class="downloadBtn greyButton" target="_blank" href="'+player_quality_240p+'"><i></i>240p</a>'

				tab.innerHTML = dwlinks
			}
		}
	},false)

	function addStyle() {
		// While <head> is not loaded we keep trying
		if (!document.querySelector("head"))
			return setTimeout(addStyle, 50)

		// We create an object and start including its content to include in DOM at the end
		var ephcss =
		// Hide ads while we can't remove them
		"iframe, aside, figure," +
		// Ad area in gifs page
		".gifsWrapper > div:first-child," +
		// Remove Ads links, Ads by TrafficJunkie notice
		".removeAdsStyle, .ad-link," +
		// Video being watched in one line, Ad Block Message, Change language notice
		".videos-being-watched li:last-child, .abAlertShown, #countryRedirectMessage {\
			display: none !important;\
		}" +
		// Where ads once were the element has a fixed width, this zeros the width if there are no childs
		".sectionTitle + div, .sectionTitle + div div, .recommendationsHiddenMessage + div, .recommendationsHiddenMessage + div div, #check .reset + div, #check .reset + div div, .nf-videos > .sectionWrapper > .clear + div, .nf-videos > .sectionWrapper > .clear + div div {\
			width: auto !important;\
		}" +
		// Gifs page
		".gifsWrapper ul.gifs li.first {\
			margin-right: 12px !important;\
		}"

		// Inject created CSS
		var ephnode = document.createElement("style")
			ephnode.type = "text/css"
			ephnode.id = "EPH-style"
			ephnode.appendChild(document.createTextNode(ephcss))
		document.head.appendChild(ephnode)
	}
}();

// Scroll, keyboard shortcut
function videoFunctions() {
	document.getElementById("hd-rightColVideoPage").setAttribute("class", "wide")
	document.getElementById("player").setAttribute("class", "wide")

	checkImage()

	// wait while player doesn't load
	function html5player() {
		var flash = document.querySelector("#player object"),
			html5 = document.querySelector("#player video")
		if (flash == null && html5 == null)
			return setTimeout(html5player, 50)
	
		var vidId = parseInt(document.getElementById('player').getAttribute("data-video-id")),
			playerDiv = document.getElementById("playerDiv_"+vidId)
		playerDiv.setAttribute("class", playerDiv.getAttribute("class") + " wide")
		scrollthere()
	}

	// Scroll video to middle of page
	function scrollthere() {
		var player = document.getElementById('player'),
			vh = player.offsetHeight,
			vd = document.querySelector(".container").offsetTop + document.querySelector(".container").parentNode.offsetTop + document.querySelector(".video-wrapper").offsetTop,
			fh = window.innerHeight;
			sc = vd-((fh-vh)/2)
		scrollTo(0, sc)
		//console.info("** ExtendPornHub **\ntop: "+vd+", height: "+vh+", scrolled: "+sc+", window: "+fh)
	}
	// Inject this function to page
	var script = document.createElement("script")
	script.setAttribute("type", "text/javascript")
	script.innerHTML = scrollthere.toString() + html5player.toString() + "html5player();"
	script.id = "EPH-scrollVid"
	document.body.appendChild(script)

	// Keyboard Shortcut for centring
	window.addEventListener('keyup', function(e) {
		if(e.ctrlKey && e.altKey && (e.code === "KeyC" || (e.code === undefined && e.keyCode === 67)))
			scrollthere()
	}, false)

	// Include button in right corner to center video on screen
	var node = document.createElement("div")
	node.setAttribute("style","position: fixed; bottom: 0; right: 0; cursor: pointer; border: 1px solid #313131; border-top-left-radius: 5px; color: #676767; font-weight: 700; background: #101010; text-align: center; font-size: 12px; padding: 7px 15px;z-index: 999999;")
	node.setAttribute("onclick", "scrollthere();")
	node.setAttribute("title", "Use the keyboard shortcut Ctrl+Alt+C (For other keyboard layouts use the key where C should be on the QWERTY layout)")
	node.innerHTML = "Centre"
	node.id = "EPH-scroll"
	document.body.appendChild(node)
}

// Autoplay, autoload, etc.
function changePlayer() {
	ephcpc ++;
	if (ephcpc > 100)
		return;
	if (!document.getElementById('noPlayerMsg'))
		return setTimeout(changePlayer, 50)
		
	var player = document.getElementById('player'),
		vidId = parseInt(player.getAttribute("data-video-id")),
		newflashvars = document.createElement("script")
	newflashvars.setAttribute("type", "text/javascript")
	newflashvars.id = "EPH-newflashvars"
	newflashvars.innerHTML =
		'flashvars_'+vidId+'.autoplay = false;'+
		'flashvars_'+vidId+'.autoload = true;'+
		'flashvars_'+vidId+'.htmlPauseRoll = false;'+
		'flashvars_'+vidId+'.htmlPostRoll = false;'+
		'flashvars_'+vidId+'.video_unavailable_country = false;'
	document.head.appendChild(newflashvars)
}

// Add thumbnail tab
function checkImage() {
	ephcic ++;
	if (ephcic > 100)
		return;
	if (!document.querySelector(".mhp1138_thumbnailPreload"))
		return setTimeout(checkImage, 50)

	var thumbs = document.querySelector(".mhp1138_thumbnailPreload").childNodes,
		tabsHolder = document.querySelector("#js-shareData").firstChild,
		tabsContentHolder = document.querySelector(".video-actions-tabs"),
		thumbstab = document.createElement("div"),
		thumbstabContent = document.createElement("div")

	thumbstab.setAttribute("class", "tab-menu-wrapper-cell")
	thumbstab.innerHTML = "<div class='tab-menu-item tooltipTrig' data-tab='thumbnails-tab' data-title='View thumbnails'><span>Thumbnails</span></div>"
	tabsHolder.appendChild(thumbstab)

	thumbstabContent.setAttribute("class", "video-action-tab thumbnails-tab")
	for (var i = 0; i < thumbs.length; i++)
		thumbstabContent.innerHTML += "<img src='"+thumbs[i].src+"'/>"
	tabsContentHolder.appendChild(thumbstabContent)
}