// ==UserScript==
// @name         Baidu Download Limit
// @namespace    https://greasyfork.org/en/scripts/19677-baidu-download-limit
// @version      2.27
// @description  scripts are enabled in your browser!
// @author       http://pastebin.com/u/NOH_789
// @match        http://pan.baidu.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

/* jshint -W097 */

'use strict';
Object.defineProperty(navigator,"platform",{value:"sb_baidu",writable:false,configurable:false,enumerable:true});